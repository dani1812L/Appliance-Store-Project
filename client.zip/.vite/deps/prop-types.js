import {
  require_prop_types
} from "./chunk-J2IKH2O7.js";
import "./chunk-G3PMV62Z.js";
export default require_prop_types();
