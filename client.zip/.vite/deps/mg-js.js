import {
  require_jsx_runtime
} from "./chunk-J3GJSMK3.js";
import {
  require_react
} from "./chunk-32E4H3EV.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/mg-js/esm/hooks/useLazyScrolling.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var import_react = __toESM(require_react());
var useLazyScrolling = ({ distance = "0px", initPage = 0 } = {}, callback) => {
  const ref = (0, import_react.useRef)(null);
  const refPage = (0, import_react.useRef)(initPage);
  const Intersector = (0, import_react.useCallback)(() => {
    return (0, import_jsx_runtime.jsx)("div", { style: { height: "1px", width: "1px" }, className: "intersector", ref });
  }, []);
  (0, import_react.useEffect)(() => {
    let observer = new IntersectionObserver(([{ isIntersecting }]) => {
      console.log("intrersecting");
      if (isIntersecting) {
        callback(refPage.current++);
      }
    }, { root: null, rootMargin: distance });
    observer.observe(ref.current);
    return () => observer.unobserve(ref.current);
  }, []);
  return { Intersector };
};
var useLazyScrolling_default = useLazyScrolling;

// node_modules/mg-js/esm/components/If.js
var If = ({ children, condition }) => {
  if (condition)
    return children;
};
var If_default = If;

// node_modules/mg-js/esm/utils/timeAgo.js
var timeAgo = (time, language) => {
  time = Number(time);
  switch (typeof time) {
    case "number":
      break;
    case "string":
      time = +new Date(time);
      break;
    default:
      time = +/* @__PURE__ */ new Date();
  }
  let time_formats;
  if (language == "En") {
    time_formats = [
      [60, "seconds", 1],
      [120, "One minute ago", "In a minute"],
      [3600, "minutes", 60],
      [7200, "one hour ago", "In a hour"],
      [86400, "hours", 3600],
      [172800, "Yesterday", "Tomorrow"],
      [604800, "days", 86400],
      [1209600, "Week ago", "Next week"],
      [2419200, "weeks", 604800],
      [4838400, "Month ago", "Next month"],
      [29030400, "two month", 2419200],
      [58060800, "Year ago", "Next year"],
      [290304e4, "years", 29030400],
      [580608e4, "The last century", "Next century"],
      [580608e5, "century", 290304e4]
    ];
  }
  if (language == "Heb") {
    time_formats = [
      [60, "שניות", 1],
      [120, "לפני דקה 1", "בעוד דקה"],
      [3600, "דקות", 60],
      [7200, "לפני שעה אחת", "בעוד שעה"],
      [86400, "שעות", 3600],
      [172800, "אתמול", "מחר"],
      [604800, "ימים", 86400],
      [1209600, "לפני שבוע", "שבוע הבא"],
      [2419200, "שבועות", 604800],
      [4838400, "לפני חודש", "חודש הבא"],
      [29030400, "חודשים", 2419200],
      [58060800, "לפני שנה", "שנה הבאה"],
      [290304e4, "שנים", 29030400],
      [580608e4, "המאה הקודמת", "במאה הבאה"],
      [580608e5, "מאות", 290304e4]
    ];
  }
  let seconds = (+/* @__PURE__ */ new Date() - time) / 1e3;
  let token;
  if (language == "En") {
    token = "Before";
  }
  if (language == "Heb") {
    token = "לפני";
  }
  let list_choice = 1;
  if (Math.floor(seconds) === 0) {
    if (language == "En")
      return "At this moment";
    if (language == "Heb")
      return "ברגע זה";
  }
  if (seconds < 0) {
    seconds = Math.abs(seconds);
    if (language == "En")
      token = "In";
    ;
    if (language == "Heb")
      token = "ב";
    list_choice = 2;
  }
  let i = 0, format;
  while (format = time_formats[i++])
    if (seconds < format[0]) {
      if (typeof format[2] == "string")
        return format[list_choice];
      else {
        return token + " " + Math.floor(seconds / format[2]) + " " + format[1];
      }
    }
  return time;
};
var timeAgo_default = timeAgo;

// node_modules/mg-js/esm/hooks/useObjectState.js
var import_react2 = __toESM(require_react());
var useObjectState = (initObject) => {
  const initialization = () => {
    let init = {};
    if (Array.isArray(initObject)) {
      initObject.forEach((key) => {
        if (typeof key === "object") {
          for (let innerKey in key) {
            init[innerKey] = key[innerKey];
          }
        } else {
          init[key] = "";
        }
      });
      return init;
    }
    return initObject;
  };
  const [state, setState] = (0, import_react2.useState)(initialization);
  const updateState = (keyOrObject, value) => {
    if (typeof keyOrObject === "object") {
      setState(Object.assign(Object.assign({}, state), keyOrObject));
    } else {
      setState(Object.assign(Object.assign({}, state), { [keyOrObject]: value }));
    }
  };
  const resetState = (resetVal) => {
    for (let key in state) {
      state[key] = resetVal;
    }
    setState(Object.assign({}, state));
  };
  return [state, updateState, resetState];
};
var useObjectState_default = useObjectState;

// node_modules/mg-js/esm/components/MediaQuery.js
var import_react3 = __toESM(require_react());
var MediaQuery = ({ minWidth, maxWidth, children }) => {
  const [isMatch, setIsMatch] = (0, import_react3.useState)(false);
  (0, import_react3.useEffect)(() => {
    let mediaQuery = "";
    if (minWidth && maxWidth) {
      mediaQuery = `(min-width: ${minWidth}px) and (max-width: ${maxWidth}px)`;
    } else if (minWidth) {
      mediaQuery = `(min-width: ${minWidth}px)`;
    } else if (maxWidth) {
      mediaQuery = `(max-width: ${maxWidth}px)`;
    }
    const media = window.matchMedia(mediaQuery);
    setIsMatch(media.matches);
    media.addEventListener("change", ({ matches }) => {
      setIsMatch(matches);
    });
  }, []);
  if (isMatch)
    return children;
};
var MediaQuery_default = MediaQuery;
export {
  If_default as If,
  MediaQuery_default as MediaQuery,
  timeAgo_default as timeAgo,
  useLazyScrolling_default as useLazyScrolling,
  useObjectState_default as useObjectState
};
//# sourceMappingURL=mg-js.js.map
