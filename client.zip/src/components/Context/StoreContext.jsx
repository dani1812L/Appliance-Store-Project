import React, { createContext } from "react";

// מין צינור שמעביר את המידע על המוצרים
const StoreContext = createContext();

export default StoreContext;
