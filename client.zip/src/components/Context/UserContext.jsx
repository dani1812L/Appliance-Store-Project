import React, { createContext } from "react";

// מין צינור שמעביר את המידע על המשתמשים
const UserContext = createContext();

export default UserContext;
